export default {
    // apicom: 'http://sss.hongbao19.net/'
    apicom: 'http://ck.hongbao19.net'
}
