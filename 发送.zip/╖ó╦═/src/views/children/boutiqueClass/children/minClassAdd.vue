<template>
  <div class="minClassAdd-container">
    <div class="articleEntry-header">当前位置&nbsp;:&nbsp;&nbsp;
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">精品课堂</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/' }">微课堂</el-breadcrumb-item>
        <el-breadcrumb-item><span>新增</span></el-breadcrumb-item>
      </el-breadcrumb>
    </div>

    <div class="articleEntry-main">

      <div class="articleEntry-main-input top">
        <div>课堂名称</div>
        <el-input v-model="title" style="width:900px"></el-input>
      </div>
       
      <div class="content_top">
          <span style="position:relative;top:-230px;left:-15px;font-weight:700" >内容</span>
          <div>
              <ediTor  v-model="content"  class="quill-editor editor" size="small" style="display:inline-block;max-height:200px;height:200px;">>

              </ediTor>
          </div>
      </div>
      <div class="articleEntry-main-input top">
        <div>视频标题</div>
        <el-input v-model="videoTitle" style="width:500px"></el-input>
      </div>

    <div class="articleEntry-main-input top colors">
            <div>视频上传</div>
              



            </div>


      <div class="articleEntry-main-input top">
        <div>主图</div>
        <el-upload
          action="http://ck.hongbao19.net/index/index/uploadimg"
            list-type="picture-card"
            :on-preview="handlePictureCardPreview"
            :before-remove="beforeRemove"
            :on-remove="handleRemove"
            :file-list="img_list"
            :on-success="uploadSuccess"
            :before-upload="beforeAvatarUpload"
            :limit="1"
            :on-exceed="onexceed"
        >
          <img src="./articleImages/添加加号无边框.png" alt="">
          <img v-if="imageUrl" :src="imageUrl" class="avatar">
        </el-upload>
      </div>



    <div class="articleEntry-main-input tiny-input">
        <div>课程节数</div>
        <el-input v-model="classroom" style="width:200px">
          <template slot="suffix">/节</template>
        </el-input>
      </div>

      <div class="articleEntry-main-input  tiny-input">
        <div>课程价格</div>
        <el-input v-model="price" style="width:200px">
           <template slot="suffix">/元</template>
        </el-input>
      </div>




      <div class="articleEntry-main-input">
        <div>类别</div>
         <el-radio-group v-model="resource">
            <el-radio label="疫苗"></el-radio>
            <el-radio label="婴儿"></el-radio>
            <el-radio label="活动"></el-radio>
            <el-radio label="专题"></el-radio>
         </el-radio-group>
      </div>
        
     <div class="articleEntry-main-input">
        <div>排序</div>
        <el-input v-model="sort" style="width:900px"></el-input>
      </div>

       <div class="articleEntry-main-input">
        <div>展示</div>
         <el-radio-group v-model="show">
            <el-radio label="显示"></el-radio>
            <el-radio label="隐藏"></el-radio>
         </el-radio-group>
      </div>

      <div class="articleEntry-main-input top">
          <el-button type="primary">提交</el-button>
      </div>

    </div>
  </div>
</template>

<script>
export default {
  name: "minClassAdd",
  data() {
    return {
      title:'',
      content:'',
      videoTitle:'',
      Video:'',
      imageUrl:'',
      classroom:'',
      price:'',
      resource:'疫苗',
      sort:'',
      show:'显示',

      videoFlag:false,
      paramsdata:{}
    };
  },
 methods:{
      // //视频验证格式和大小
      // beforeUploadVideo(file) {
      //     const isLt10M = file.size / 1024 / 1024  < 10;
      //     if (['video/mp4', 'video/ogg', 'video/flv','video/avi','video/wmv','video/rmvb'].indexOf(file.type) == -1) {
      //         this.$message.error('请上传正确的视频格式');
      //         return false;
      //     }
      //     if (!isLt10M) {
      //         this.$message.error('上传视频大小不能超过10MB哦!');
      //         return false;
      //     }
      // },
      //视频上传进度显示
      uploadVideoProcess(event, file, fileList){
          this.videoFlag = true;
          this.videoUploadPercent = file.percentage.toFixed(0);
      },
      //上传成功
      handleVideoSuccess(res, file) { 
        console.log(res,file)                            
          // this.videoFlag = false;
          // this.videoUploadPercent = 0;
          if(res.status == 200){
              // this.videoForm.videoUploadId = res.data.uploadId;
              // this.videoForm.Video = res.data.uploadUrl;
          }else{
              this.$message.error('视频上传失败，请重新上传！');
          }
      },


handleRemove(file, fileList) {
      this.img_list = fileList;
    },
    // 点击上传的文件的钩子
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`);
    },
    onexceed(files, fileList) {
      this.$message.warning("只能上传一张图片!");
    },
    // 上传成功
    uploadSuccess(response, file, fileList) {
      //点击延时
      // setTimeout(() => {
      //    this.uploadDisabled = 1;
      //    that.isDisabled = false;
      // }, 1000);
    },
    // 上传之前
    beforeAvatarUpload(file) {
      var that = this;
      // 判断类型是不是图片
      if (!/image\/\w+/.test(file.type)) {
        that.$message("请确保文件为图像类型");
        return false;
      } else {
        var article_image, image_base64;
        var reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function(e) {
          image_base64 = this.result.split(",")[1];
          article_image = image_base64;
          var params = {
            imgdata: article_image
          };
          that.$http
            .post("http://ck.hongbao19.net/index/index/uploadimg", params)
            .then(res => {
              if (res.data.status == 1) {
                that.imageUrl = res.data.result.imgurl;
              }
            });
        };
      }
    },
  }
}
</script>

<style lang="less">
.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
.minClassAdd-container {
  height: 100%;
  .articleEntry-header {
    height: 80px;
    border-bottom: 1px solid #eee;
    display: flex;
    align-items: center;
    padding-left: 40px;
    font-size: 14px;
    color:#A9A9A9;
    .el-breadcrumb__inner{
        color:#A9A9A9;
        span{
          color:#00979C;
        }
    }
  }
  .articleEntry-main {
    .top{
        margin-top: 25px;
    }
    .colors{
      .el-upload{
        background-color: #E0E0E0; 
      }
    }
    .content{
      input{
        height: 300px;
      }
    }
    .articleEntry-main-input {
    //   margin-top: 25px;
      display: flex;
      padding-left: 100px;
      img{
        position: absolute;
        top:50%;
        left: 50%;
        transform: translate(-50%,-50%);
      }
      p{
        position: absolute;
        top:50%;
        left: 50%;
        transform: translate(-50%,0%);
        color:#999999;
        font-size: 12px;
      }
      .el-upload{
          width: 200px;
          height: 120px;
      }
      div {
        width: 60px;
        line-height: 50px;
        text-align: center;
        margin-right: 20px;
        font-weight: 700;
        font-size: 14px;
      }
      .el-textarea__inner{
          width: 900px;
          height: 318px;
          resize: none;
      }
      // input {
      //   width: 900px;
      // }
      .el-radio-group{
            display: flex;
            align-items: center;
        }
        button{
            width: 150px;
            margin-left: 80px;
            margin-bottom: 60px;
        }
        .el-icon-plus{
          display: none;
        }
    }
  }
}
</style>
